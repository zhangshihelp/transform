package me.zs.mapper;

import me.zs.domain.User;

import java.util.List;

public interface UserMapper {

    List<User> queryUserList();
}
