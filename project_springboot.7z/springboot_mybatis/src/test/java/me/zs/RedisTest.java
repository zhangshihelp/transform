package me.zs;

import com.fasterxml.jackson.databind.ObjectMapper;
import me.zs.domain.User;
import me.zs.mapper.UserMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringbootMybatisApplicationTests.class)
public class RedisTest {

    // 一直报错，待后续解决
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired(required = false)
    private UserMapper userMapper;

    @Test
    public void testRedis() throws Exception {
        //1.从redis中获得数据，数据形式json字符串
        if (redisTemplate == null) {
            return;
        }
        String userListJson = redisTemplate.boundValueOps("user.queryUserList").get();
        //2.判断redis中是否存在数据
        if (null == userListJson) {
            //3.不存在数据，从数据库查询
            List<User> users = userMapper.queryUserList();
            //4.将查询到的数据存储到redis缓存中
            //4.1将list集合转换成json格式的字符串，实用Jsckson进行转换
            ObjectMapper objectMapper = new ObjectMapper();
            userListJson = objectMapper.writeValueAsString(users);
            redisTemplate.boundValueOps("user.queryUserList").set(userListJson);

            System.out.println("=======从数据库中获得user的数据======");
        } else {
            System.out.println("=======从redis缓存中获得user的数据======");
        }
        //4.将数据在控制台打印
        System.out.println(userListJson);
    }
}
